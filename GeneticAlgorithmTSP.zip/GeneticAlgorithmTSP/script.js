// مسأله فروشنده دوره‌گرد: لیست شهرها (به عنوان مثال ۵ شهر)
const cities = [
  { x: 60, y: 200 }, // شهر 1
  { x: 180, y: 200 }, // شهر 2
  { x: 80, y: 180 },  // شهر 3
  { x: 140, y: 180 }, // شهر 4
  { x: 20, y: 160 }   // شهر 5
];

// تابع برای محاسبه فاصله بین دو شهر
function calculateDistance(city1, city2) {
  return Math.sqrt(Math.pow(city2.x - city1.x, 2) + Math.pow(city2.y - city1.y, 2));
}

// ساخت کروموزوم (مسیر فروشنده)
function createChromosome() {
  let chromosome = [...cities];
  chromosome = shuffleArray(chromosome);
  return chromosome;
}

// شافل آرایه (ترتیب تصادفی شهرها)
function shuffleArray(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// تابع برای محاسبه طول مسیر کروموزوم
function calculatePathLength(chromosome) {
  let length = 0;
  for (let i = 0; i < chromosome.length - 1; i++) {
    length += calculateDistance(chromosome[i], chromosome[i + 1]);
  }
  // اضافه کردن فاصله از آخرین شهر به اولین شهر
  length += calculateDistance(chromosome[chromosome.length - 1], chromosome[0]);
  return length;
}

// تابع برای ایجاد نسل جدید
function createNewGeneration(population) {
  const newGeneration = [];
  for (let i = 0; i < population.length; i++) {
    const parent1 = population[Math.floor(Math.random() * population.length)];
    const parent2 = population[Math.floor(Math.random() * population.length)];
    const offspring = crossover(parent1, parent2);
    newGeneration.push(offspring);
  }
  return newGeneration;
}

// عملگر تلاقی (Crossover)
function crossover(parent1, parent2) {
  const crossoverPoint = Math.floor(Math.random() * parent1.length);
  const offspring = [...parent1.slice(0, crossoverPoint), ...parent2.slice(crossoverPoint)];
  return offspring;
}

// عملگر موتاسیون (Mutation)
function mutate(chromosome) {
  const mutationRate = 0.1;
  if (Math.random() < mutationRate) {
    const swapIndex1 = Math.floor(Math.random() * chromosome.length);
    const swapIndex2 = Math.floor(Math.random() * chromosome.length);
    [chromosome[swapIndex1], chromosome[swapIndex2]] = [chromosome[swapIndex2], chromosome[swapIndex1]];
  }
  return chromosome;
}

// شروع الگوریتم ژنتیک
function runGeneticAlgorithm() {
  const populationSize = 100;
  let population = [];

  // ساخت نسل اولیه
  for (let i = 0; i < populationSize; i++) {
    population.push(createChromosome());
  }

  let bestPath = null;
  let bestLength = Infinity;

  for (let generation = 0; generation < 1000; generation++) {
    population = createNewGeneration(population);

    // اعمال موتاسیون
    population = population.map(chromosome => mutate(chromosome));

    // ارزیابی بهترین مسیر
    population.forEach(chromosome => {
      const length = calculatePathLength(chromosome);
      if (length < bestLength) {
        bestLength = length;
        bestPath = chromosome;
      }
    });

    // نمایش نتیجه
    if (generation % 100 === 0) {
      console.log(`Generation ${generation}: Best path length = ${bestLength}`);
    }
  }

  // نمایش بهترین مسیر
  alert(`Best path found: ${bestPath.map(city => `(${city.x}, ${city.y})`).join(' -> ')}\nTotal length: ${bestLength}`);
}

// اضافه کردن رویداد به دکمه
document.getElementById("runAlgorithm").addEventListener("click", runGeneticAlgorithm);
